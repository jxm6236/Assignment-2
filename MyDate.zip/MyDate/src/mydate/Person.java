/**
	File name: Person.java
	Short description: Displays Info about employees
	IST 311 Assignment: #2
	@author Jimmy McGettigan
	@version 1.01  9/30/2019
*/
package mydate;

/**
 *
 * @author jmhaz
 */
public class Person{
    
}
